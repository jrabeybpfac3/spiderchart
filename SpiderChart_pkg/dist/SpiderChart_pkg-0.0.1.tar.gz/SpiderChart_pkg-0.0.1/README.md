# SpiderChart Package

This is a simple python app with no documentation yet (sorry)